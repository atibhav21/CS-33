/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_365()
{
    return 3347662926U;
}

void setval_328(unsigned *p)
{
    *p = 3281162328U;
}

void setval_428(unsigned *p)
{
    *p = 3267856712U;
}

unsigned getval_359()
{
    return 2421704562U;
}

unsigned getval_371()
{
    return 2425378833U;
}

void setval_331(unsigned *p)
{
    *p = 3281031192U;
}

void setval_399(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_477(unsigned x)
{
    return x + 3347663445U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_137(unsigned x)
{
    return x + 3286239560U;
}

void setval_236(unsigned *p)
{
    *p = 3281044169U;
}

unsigned addval_432(unsigned x)
{
    return x + 3229929129U;
}

void setval_305(unsigned *p)
{
    *p = 3234124169U;
}

unsigned getval_263()
{
    return 3676885385U;
}

unsigned getval_287()
{
    return 3374371211U;
}

void setval_206(unsigned *p)
{
    *p = 3523793321U;
}

unsigned getval_462()
{
    return 2425409945U;
}

unsigned addval_141(unsigned x)
{
    return x + 3374371209U;
}

unsigned addval_467(unsigned x)
{
    return x + 3286272330U;
}

void setval_203(unsigned *p)
{
    *p = 3223899785U;
}

unsigned addval_282(unsigned x)
{
    return x + 3223899785U;
}

unsigned addval_113(unsigned x)
{
    return x + 3525365377U;
}

unsigned addval_465(unsigned x)
{
    return x + 3767093402U;
}

unsigned getval_142()
{
    return 2447411528U;
}

void setval_229(unsigned *p)
{
    *p = 3378561673U;
}

void setval_471(unsigned *p)
{
    *p = 3525366145U;
}

void setval_195(unsigned *p)
{
    *p = 3676361097U;
}

void setval_205(unsigned *p)
{
    *p = 2464188744U;
}

void setval_285(unsigned *p)
{
    *p = 3281044109U;
}

unsigned addval_443(unsigned x)
{
    return x + 3677930121U;
}

unsigned addval_386(unsigned x)
{
    return x + 3523792521U;
}

unsigned getval_472()
{
    return 3525365385U;
}

unsigned addval_484(unsigned x)
{
    return x + 3767093329U;
}

void setval_186(unsigned *p)
{
    *p = 3938701001U;
}

unsigned addval_300(unsigned x)
{
    return x + 2428668229U;
}

unsigned addval_321(unsigned x)
{
    return x + 3372270217U;
}

void setval_363(unsigned *p)
{
    *p = 3380920841U;
}

void setval_145(unsigned *p)
{
    *p = 3252717896U;
}

void setval_135(unsigned *p)
{
    *p = 3286272360U;
}

unsigned getval_243()
{
    return 3378561673U;
}

unsigned getval_318()
{
    return 3375943369U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
